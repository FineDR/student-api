# data.py

students_data = [
    {"name": "Alice", "enrolled_program": "Software Engineering"},
    {"name": "Bob", "enrolled_program": "Software Engineering"},
    {"name": "Charlie", "enrolled_program": "Software Engineering"},
    {"name": "David", "enrolled_program": "Software Engineering"},
    {"name": "Eve", "enrolled_program": "Software Engineering"},
    {"name": "Frank", "enrolled_program": "Software Engineering"},
    {"name": "Grace", "enrolled_program": "Software Engineering"},
    {"name": "Hannah", "enrolled_program": "Software Engineering"},
    {"name": "Ivy", "enrolled_program": "Software Engineering"},
    {"name": "Jack", "enrolled_program": "Software Engineering"},
]

subjects_data = [
    {"name": "Introduction to Programming", "year": 1},
    {"name": "Computer Systems", "year": 1},
    {"name": "Mathematics for Computing", "year": 1},
    {"name": "Data Structures", "year": 2},
    {"name": "Databases", "year": 2},
    {"name": "Software Engineering Principles", "year": 2},
    {"name": "Web Development", "year": 3},
    {"name": "Machine Learning", "year": 3},
    {"name": "Operating Systems", "year": 3},
    {"name": "Cybersecurity", "year": 4},
    {"name": "Cloud Computing", "year": 4},
    {"name": "Advanced Software Engineering", "year": 4},
]
